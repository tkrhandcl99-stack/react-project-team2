import React from 'react';
import { ExternalLink, Phone } from 'lucide-react';

const PlaceDetailCard = ({ place, onClose }) => {
  if (!place) return null;

  return (
    <div
      className="absolute top-20 left-1/2 -translate-x-1/2 z-[1001] flex items-center bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl p-2 border border-slate-100 animate-in fade-in zoom-in duration-300"
      style={{ width: '310px', height: '75px' }} // 💡 가로를 310px로 더 줄여서 콤팩트하게 변경
    >
      {/* 🖼️ 이미지 공간 */}
      <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 flex items-center justify-center border border-slate-50">
        <span className="text-[10px] text-slate-300 font-bold">IMAGE</span>
      </div>

      {/* 📝 정보 영역: flex-1을 유지하되 내부 여백을 조절 */}
      <div className="ml-3 flex-1 flex flex-col justify-center min-w-0 text-left pr-1">
        <div className="flex items-start justify-between gap-1 mb-0.5">
          <div className="min-w-0">
            <h3 className="text-sm font-black text-slate-800 truncate leading-tight">
              {place.place_name}
            </h3>
            <p className="text-[10px] text-slate-400 truncate mt-0.5">
              {place.address_name}
            </p>
          </div>

          {/* 🔗 [최종 버튼] 주황색을 더 강조하고 크기를 최적화 */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              window.open(place.place_url, '_blank', 'noopener,noreferrer');
            }}
            className="flex items-center gap-1 text-[10px] font-bold text-white bg-[#F05A28] px-2 py-1.5 rounded-lg hover:bg-orange-600 transition-all active:scale-95 flex-shrink-0 cursor-pointer shadow-sm shadow-orange-100"
          >
            정보 <ExternalLink size={10} />
          </button>
        </div>

        {/* 하단 전화번호 */}
        <div className="flex items-center gap-1 text-[9px] text-slate-300">
          <Phone size={8} className="text-slate-300" />
          <span>{place.phone || '연락처 없음'}</span>
        </div>
      </div>

      {/* ✕ 닫기 버튼: 위치를 살짝 안으로 조정 */}
      <button
        onClick={onClose}
        className="absolute -top-1.5 -right-1.5 bg-white text-slate-400 rounded-full w-5 h-5 flex items-center justify-center text-[10px] shadow-md border border-slate-100 cursor-pointer hover:text-slate-600"
      >
        ✕
      </button>
    </div>
  );
};

export default PlaceDetailCard;
