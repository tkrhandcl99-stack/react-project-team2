from flask import Flask, request, jsonify
from flask_cors import CORS
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time
import re

app = Flask(__name__)
CORS(app)

def get_kakao_image(place_url):
    if not place_url: return None
    
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    # 실제 브라우저처럼 보이기 위한 설정
    chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36")
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    
    try:
        driver.get(place_url)
        time.sleep(3) # 💡 페이지 로딩 시간을 조금 더 넉넉히 줍니다 (3초)

        # 🎯 필살기 1: 카카오맵의 '메인 사진' 클래스 직접 타격
        try:
            # 카카오맵 상세페이지의 메인 사진은 보통 link_photo 클래스 안의 배경이미지입니다.
            photo_element = driver.find_element(By.CSS_SELECTOR, ".link_photo")
            style = photo_element.get_attribute("style")
            if "url" in style:
                match = re.search(r'url\("?(.+?)"?\)', style)
                if match:
                    img_url = match.group(1)
                    if img_url.startswith("//"): img_url = "https:" + img_url
                    return img_url
        except:
            pass

        # 🎯 필살기 2: 페이지 내의 모든 img 태그 중 'kakaocdn' 주소를 포함한 첫 번째 이미지 찾기
        try:
            images = driver.find_elements(By.TAG_NAME, "img")
            for img in images:
                src = img.get_attribute("src")
                # 카카오 서버에 저장된 진짜 이미지 주소 패턴을 찾습니다.
                if src and ("kakaocdn.net" in src or "dn-mimetypes" not in src):
                    if "t1.kakaocdn.net" in src:
                        return src
        except:
            pass
            
        return None
    except Exception as e:
        print(f"에러 발생: {e}")
        return None
    finally:
        driver.quit()

@app.route('/api/get-image')
def get_image():
    url = request.args.get('url')
    # http를 https로 강제 변환
    if url and url.startswith("http://"):
        url = url.replace("http://", "https://")
        
    print(f"--- [추출 시도] URL: {url} ---")
    image_url = get_kakao_image(url)
    print(f"--- [추출 성공!] 이미지 URL: {image_url} ---") # 👈 여기가 None이 아니어야 함!
    return jsonify({"imageUrl": image_url})

if __name__ == '__main__':
    app.run(port=5000, debug=True)